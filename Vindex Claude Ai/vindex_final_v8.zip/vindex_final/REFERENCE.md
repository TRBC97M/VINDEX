# Référence du langage VINDEX

Cette référence documente ce qui **fonctionne réellement**, vérifié
empiriquement par des programmes de test exécutés, pas ce qui était prévu
à l'origine du projet. Là où quelque chose existe dans le vocabulaire mais
ne fonctionne pas, c'est dit explicitement.

VINDEX compile directement vers des exécutables ELF x86-64 Linux, sans
dépendance externe. Le compilateur (`compilator_decalage.vindex`) est lui
même écrit en VINDEX et auto-hébergé (point fixe stable confirmé : se
recompiler soi-même produit un binaire identique au bit près).

*Le nom vient du droit romain : le "vindex" était celui qui intervenait
légalement pour affranchir un esclave — un défenseur face au pouvoir
établi.*

## Structure d'un programme

Tout programme VINDEX a besoin d'une fonction `PRINCIPALIS` — le point
d'entrée.

```
FUNCTIO PRINCIPALIS REDDENS NUMERUS.
    PROCLAMA "Salve, mundus!".
    REDDE 0.
FIN-FUNCTIO.
```

Chaque instruction se termine par un point. Les blocs s'ouvrent par leur
mot-clé et se ferment par un `FIN-` correspondant.

## Fonctions

```
FUNCTIO NOM_FONCTION REDDENS NUMERUS.
    ACCIPIT a SICUT NUMERUS.
    ACCIPIT b SICUT NUMERUS.
    REDDE a + b.
FIN-FUNCTIO.
```

- `ACCIPIT nom SICUT type.` déclare un paramètre.
- `REDDENS type` déclare le type de retour. `VACUUM` est utilisable pour
  signaler qu'une fonction n'a pas de valeur de retour significative —
  dans ce cas, terminez quand même par `REDDE 0.` par convention (le
  compilateur n'impose pas de restriction stricte sur la valeur, `VACUUM`
  est avant tout une indication pour le lecteur du code).
- `REDDE expression.` retourne une valeur et sort de la fonction.
- **6 paramètres maximum** par fonction (limite des registres du
  processeur — un 7ᵉ paramètre nécessiterait un passage par la pile, non
  implémenté).
- Les références en avant fonctionnent : une fonction peut en appeler une
  autre définie plus loin dans le fichier.
- La récursion fonctionne, y compris profonde.

## Types

| Type | Description | Vérifié |
|---|---|---|
| `NUMERUS` | Entier signé 64 bits | ✅ |
| `LITTERA` | Un caractère/octet | ✅ |
| `VERITAS` | Booléen (0 ou 1) | ✅ |
| `ACUS<T>` | Pointeur vers un `T` (types de base et structures) | ✅ |
| `ORDO DE T CAPACITAS n` | Tableau de `n` éléments de type `T` | ✅ |
| `FORMA` (structure) | Type composite avec champs (`CAMPUS`) | ✅ |
| `VACUUM` | Type de retour "sans valeur significative" | ✅ |

Il n'y a **pas de type flottant**. Uniquement des entiers.

### Déclaration de variables

```
DECLARA x SICUT NUMERUS VALENS 42.
DECLARA tab SICUT ORDO DE NUMERUS CAPACITAS 10.
DECLARA texte SICUT ORDO DE LITTERA CAPACITAS 20.
```

### Structures (`FORMA`)

```
FORMA Punctum.
    CAMPUS x SICUT NUMERUS.
    CAMPUS y SICUT NUMERUS.
FIN-FORMA.

FUNCTIO PRINCIPALIS REDDENS NUMERUS.
    DECLARA p SICUT Punctum.
    x DE p = 3.
    y DE p = 7.
    REDDE x DE p + y DE p.
FIN-FUNCTIO.
```

L'accès à un champ se fait via `champ DE variable` — il n'y a **pas** de
notation point (`p.x` ne fonctionne pas).

### Pointeurs

```
DECLARA x SICUT NUMERUS VALENS 10.
DECLARA p SICUT ACUS<NUMERUS> VALENS SEDES(x).
CONTENTUM(p) = 99.
// x vaut maintenant 99
```

- `SEDES(variable)` — adresse d'une variable (équivalent de `&` en C).
- `CONTENTUM(pointeur)` — déréférencement (équivalent de `*` en C), en
  lecture comme en écriture.
- Passer un pointeur en paramètre de fonction pour du passage par
  référence fonctionne correctement (vérifié avec récursion profonde).
- `ACUS<T>` fonctionne aussi bien avec les types de base (`NUMERUS`,
  `LITTERA`) qu'avec une structure définie par l'utilisateur
  (`ACUS<MaStructure>`).

### Structures via pointeur

L'accès à un champ à travers un pointeur (`campo DE CONTENTUM(ptr)`)
fonctionne en lecture, en écriture, et en auto-référence (lire et
réécrire le même champ dans la même instruction) :

```
FORMA Compte.
    CAMPUS solde SICUT NUMERUS.
FIN-FORMA.

FUNCTIO DEPOSE REDDENS NUMERUS.
    ACCIPIT c SICUT ACUS<Compte>.
    ACCIPIT montant SICUT NUMERUS.
    solde DE CONTENTUM(c) = solde DE CONTENTUM(c) + montant.
    REDDE 0.
FIN-FUNCTIO.

FUNCTIO PRINCIPALIS REDDENS NUMERUS.
    DECLARA mon_compte SICUT Compte.
    solde DE mon_compte = 100.
    DECLARA ig SICUT NUMERUS VALENS DEPOSE(SEDES(mon_compte), 50).
    PROCLAMA solde DE mon_compte.
    REDDE 0.
FIN-FUNCTIO.
```

Ceci affiche `150` — le passage par référence d'une structure et sa
modification fonctionnent correctement.

## Contrôle de flux

### Condition

```
SI x > 10 TUNC
    PROCLAMA 1.
ALITER
    PROCLAMA 0.
FIN-SI.
```

`ALITER` est optionnel.

### Boucle conditionnelle

```
DECLARA i SICUT NUMERUS VALENS 0.
DUM i < 10 PERFICE
    PROCLAMA i.
    i = i + 1.
FIN-DUM.
```

### Boucle bornée

```
PER i AB 0 AD 9 PERFICE
    PROCLAMA i.
FIN-PER.
```

Boucle inclusive (`AB 0 AD 9` fait 10 itérations, de 0 à 9 inclus).

⚠️ **Portée de la variable de boucle** : réutiliser le même nom de
variable dans deux boucles `PER` séparées au sein de la même fonction a
été un vrai bug jusqu'à cette session (la seconde boucle lisait la valeur
figée de la première). C'est corrigé et vérifié.

### Sortie de boucle

```
DUM i < 100 PERFICE
    SI i == 5 TUNC
        DESINE.
    FIN-SI.
    i = i + 1.
FIN-DUM.
```

`DESINE` sort de la boucle englobante (`DUM` ou `PER`).

## Opérateurs

Tous vérifiés empiriquement, y compris avec des nombres négatifs :

| Opérateur | Signification |
|---|---|
| `+` `-` `*` | Addition, soustraction, multiplication |
| `/` | Division entière signée (tronquée vers zéro) |
| `%` | Modulo signé |
| `&` `\|` | ET / OU binaire |
| `<<` `>>` | Décalage de bits gauche/droite |
| `==` `!=` `>` `<` `>=` `<=` | Comparaisons |
| `&&` `\|\|` | ET / OU logique, avec chaînage (`a && b && c`) |

Les littéraux caractères (`'A'`) sont reconnus et valent leur code ASCII.

## Entrées/sorties

```
PROCLAMA 42.                            // affiche un nombre
PROCLAMA "Texte".                       // affiche une chaine litterale
SCRIBE tableau_littera CAPACITAS n.     // affiche un tableau de LITTERA brut

DECLARA fd SICUT NUMERUS VALENS APERI_LEGERE("fichier.txt").
DECLARA n SICUT NUMERUS VALENS LEGE(fd, 1000).   // lit jusqu'a 1000 octets
CLAUDE(fd).

DECLARA fd2 SICUT NUMERUS VALENS APERI_SCRIBERE("sortie.txt").
DECLARA ecrits SICUT NUMERUS VALENS MITTE(fd2, tableau, taille).
CLAUDE(fd2).

SCRIBE_LECTUS(n).        // affiche le contenu du dernier buffer lu par LEGE
PROCLAMA OCTETUS(0).     // acces a l'octet n du dernier buffer lu par LEGE
```

## Gestion mémoire

```
DECLARA p SICUT ACUS<NUMERUS> VALENS RESERVA(NUMERUS).
```

`RESERVA(type)` alloue de la mémoire — **implémenté comme un simple
compteur qui avance** (allocateur "bump"), jamais de récupération
d'espace.

⚠️ **`LIBERA(p)` est reconnue par le compilateur mais ne fait
strictement rien** — c'est un no-op complet, vérifié en lisant le code
généré (le compilateur analyse la syntaxe et l'ignore, sans émettre le
moindre code machine). Un programme qui alloue beaucoup dans une boucle
longue épuisera la mémoire réservée sans jamais la récupérer.

## À propos d'IMPONE et AUFER

Ces deux mots figuraient dans la conception initiale du projet, dans
l'idée de fonctions natives de pile. Ce ne sont **pas** des mots-clés du
compilateur (aucune détection spéciale) — c'est volontaire :
`IMPONE`/`AUFER` sont conçues pour être **définies par le programmeur**,
comme des fonctions VINDEX ordinaires implémentant une pile sur un
tableau. C'est l'usage établi dans le projet (voir `arbor_vindex.vindex`
pour un exemple complet, avec la convention `IMPONE(tableau,
SEDES(sommet), valeur)` / `AUFER(tableau, SEDES(sommet))`).

## Limites générales

- Un seul fichier par programme — pas de `IMPORT` ni de modules.
- Linux x86-64 uniquement, format ELF statique.
- Pas de liaison avec des bibliothèques externes (pas de libc, pas de
  `printf`, etc. — tout passe par les appels système directs).
- Le code machine généré est non optimisé (verbeux : chaque opération
  produit plusieurs instructions séparées plutôt qu'une séquence
  compacte).
- 6 paramètres maximum par fonction, 100 variables locales maximum par
  fonction.

## Exemple complet

```
FORMA Compte.
    CAMPUS solde SICUT NUMERUS.
FIN-FORMA.

FUNCTIO PRINCIPALIS REDDENS NUMERUS.
    DECLARA mon_compte SICUT Compte.
    solde DE mon_compte = 100.
    solde DE mon_compte = solde DE mon_compte + 50.
    PROCLAMA solde DE mon_compte.
    REDDE 0.
FIN-FUNCTIO.
```
