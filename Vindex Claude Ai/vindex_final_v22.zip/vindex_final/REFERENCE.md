# Référence du langage VINDEX

Cette référence documente ce qui **fonctionne réellement**, vérifié
empiriquement par des programmes de test exécutés, pas ce qui était prévu
à l'origine du projet. Là où quelque chose existe dans le vocabulaire mais
ne fonctionne pas, c'est dit explicitement.

VINDEX compile directement vers des exécutables ELF x86-64 Linux, sans
dépendance externe. Le compilateur (`compilator_decalage.vindex`) est lui
même écrit en VINDEX et auto-hébergé (point fixe stable confirmé : se
recompiler soi-même produit un binaire identique au bit près).

*Le nom vient du droit romain : le "vindex" était celui qui intervenait
légalement pour affranchir un esclave — un défenseur face au pouvoir
établi.*

## Structure d'un programme

Tout programme VINDEX a besoin d'une fonction `PRINCIPALIS` — le point
d'entrée.

```
FUNCTIO PRINCIPALIS REDDENS NUMERUS.
    PROCLAMA "Salve, mundus!".
    REDDE 0.
FIN-FUNCTIO.
```

Chaque instruction se termine par un point. Les blocs s'ouvrent par leur
mot-clé et se ferment par un `FIN-` correspondant.

## Fonctions

```
FUNCTIO NOM_FONCTION REDDENS NUMERUS.
    ACCIPIT a SICUT NUMERUS.
    ACCIPIT b SICUT NUMERUS.
    REDDE a + b.
FIN-FUNCTIO.
```

- `ACCIPIT nom SICUT type.` déclare un paramètre.
- `REDDENS type` déclare le type de retour. `VACUUM` est utilisable pour
  signaler qu'une fonction n'a pas de valeur de retour significative —
  dans ce cas, terminez quand même par `REDDE 0.` par convention (le
  compilateur n'impose pas de restriction stricte sur la valeur, `VACUUM`
  est avant tout une indication pour le lecteur du code).
- `REDDE expression.` retourne une valeur et sort de la fonction.
- **6 paramètres maximum** par fonction (limite des registres du
  processeur — un 7ᵉ paramètre nécessiterait un passage par la pile, non
  implémenté).
- Les références en avant fonctionnent : une fonction peut en appeler une
  autre définie plus loin dans le fichier.
- La récursion fonctionne, y compris profonde.

## Types

| Type | Description | Vérifié |
|---|---|---|
| `NUMERUS` | Entier signé 64 bits | ✅ |
| `LITTERA` | Un caractère/octet | ✅ |
| `VERITAS` | Booléen (0 ou 1) | ✅ |
| `ACUS<T>` | Pointeur vers un `T` (types de base et structures) | ✅ |
| `ORDO DE T CAPACITAS n` | Tableau de `n` éléments de type `T` | ✅ |
| `FORMA` (structure) | Type composite avec champs (`CAMPUS`) | ✅ |
| `VACUUM` | Type de retour "sans valeur significative" | ✅ |

Il n'y a **pas de type flottant**. Uniquement des entiers.

### Déclaration de variables

```
DECLARA x SICUT NUMERUS VALENS 42.
DECLARA tab SICUT ORDO DE NUMERUS CAPACITAS 10.
DECLARA texte SICUT ORDO DE LITTERA CAPACITAS 20.
```

### Structures (`FORMA`)

```
FORMA Punctum.
    CAMPUS x SICUT NUMERUS.
    CAMPUS y SICUT NUMERUS.
FIN-FORMA.

FUNCTIO PRINCIPALIS REDDENS NUMERUS.
    DECLARA p SICUT Punctum.
    x DE p = 3.
    y DE p = 7.
    REDDE x DE p + y DE p.
FIN-FUNCTIO.
```

L'accès à un champ se fait via `champ DE variable` — il n'y a **pas** de
notation point (`p.x` ne fonctionne pas).

### Pointeurs

```
DECLARA x SICUT NUMERUS VALENS 10.
DECLARA p SICUT ACUS<NUMERUS> VALENS SEDES(x).
CONTENTUM(p) = 99.
// x vaut maintenant 99
```

- `SEDES(variable)` — adresse d'une variable (équivalent de `&` en C).
- `CONTENTUM(pointeur)` — déréférencement (équivalent de `*` en C), en
  lecture comme en écriture. **Attention** : `CONTENTUM` lit toujours 8
  octets, quel que soit le type déclaré du pointeur (voir `OCTETUS_AB`
  ci-dessous pour lire un seul octet à une adresse).
- Passer un pointeur en paramètre de fonction pour du passage par
  référence fonctionne correctement (vérifié avec récursion profonde).
- `ACUS<T>` fonctionne aussi bien avec les types de base (`NUMERUS`,
  `LITTERA`) qu'avec une structure définie par l'utilisateur
  (`ACUS<Structura>`).

**Arithmétique de pointeur mise à l'échelle automatiquement** — `p + 1`
avance de la taille d'un élément (8 octets pour `ACUS<NUMERUS>`, 1 octet
pour `ACUS<LITTERA>`), pas d'un octet brut. L'indexation `p[i]`
fonctionne aussi directement sur un pointeur, avec la même mise à
l'échelle :

```
DECLARA tab SICUT ORDO DE NUMERUS CAPACITAS 3.
tab[0] = 10. tab[1] = 20. tab[2] = 30.
DECLARA p SICUT ACUS<NUMERUS> VALENS SEDES(tab[0]).
PROCLAMA CONTENTUM(p).       // 10
PROCLAMA CONTENTUM(p + 1).   // 20 (pas besoin d'ecrire p+8)
PROCLAMA CONTENTUM(p + 2).   // 30
p[1] = 99.
PROCLAMA tab[1].             // 99 -- l'ecriture via p modifie bien tab
```

Cette mise à l'échelle s'applique à toute mémoire adressable — tableaux
locaux, mémoire `RESERVA`, et mémoire fournie par le système
(`argv`, voir plus bas) — de façon cohérente.

### Structures via pointeur

L'accès à un champ à travers un pointeur (`campo DE CONTENTUM(ptr)`)
fonctionne en lecture, en écriture, et en auto-référence (lire et
réécrire le même champ dans la même instruction) :

```
FORMA Compte.
    CAMPUS solde SICUT NUMERUS.
FIN-FORMA.

FUNCTIO DEPOSE REDDENS NUMERUS.
    ACCIPIT c SICUT ACUS<Compte>.
    ACCIPIT montant SICUT NUMERUS.
    solde DE CONTENTUM(c) = solde DE CONTENTUM(c) + montant.
    REDDE 0.
FIN-FUNCTIO.

FUNCTIO PRINCIPALIS REDDENS NUMERUS.
    DECLARA mon_compte SICUT Compte.
    solde DE mon_compte = 100.
    DECLARA ig SICUT NUMERUS VALENS DEPOSE(SEDES(mon_compte), 50).
    PROCLAMA solde DE mon_compte.
    REDDE 0.
FIN-FUNCTIO.
```

Ceci affiche `150` — le passage par référence d'une structure et sa
modification fonctionnent correctement.

### Tableaux de structures

`ORDO DE MaStructure CAPACITAS n` réserve la bonne quantité de mémoire
(le nombre de champs de la structure multiplié par `n`), et l'accès aux
champs d'un élément indexé fonctionne en lecture comme en écriture :

```
FORMA Punctum.
    CAMPUS x SICUT NUMERUS.
    CAMPUS y SICUT NUMERUS.
FIN-FORMA.

FUNCTIO PRINCIPALIS REDDENS NUMERUS.
    DECLARA pts SICUT ORDO DE Punctum CAPACITAS 3.
    x DE pts[0] = 10.
    y DE pts[0] = 11.
    x DE pts[1] = 20.
    y DE pts[1] = 21.
    PROCLAMA x DE pts[0].
    PROCLAMA y DE pts[0].
    PROCLAMA x DE pts[1].
    PROCLAMA y DE pts[1].
    REDDE 0.
FIN-FUNCTIO.
```

### Champ tableau dans une structure

Une structure peut contenir un tableau intégré comme champ. `campo DE
variable` retourne alors l'adresse du tableau (pas une valeur), qu'on
peut stocker dans un `ACUS<T>` puis indexer normalement :

```
FORMA Buffer.
    CAMPUS taille SICUT NUMERUS.
    CAMPUS donnees SICUT ORDO DE NUMERUS CAPACITAS 5.
FIN-FORMA.

FUNCTIO PRINCIPALIS REDDENS NUMERUS.
    DECLARA b SICUT Buffer.
    taille DE b = 111.
    DECLARA d SICUT ACUS<NUMERUS> VALENS donnees DE b.
    d[0] = 10.
    d[1] = 20.
    PROCLAMA taille DE b.
    PROCLAMA d[0].
    PROCLAMA d[1].
    REDDE 0.
FIN-FUNCTIO.
```

## Nombres à virgule flottante

`FLOTANS` est un type à part entière (double précision IEEE-754, 8
octets), avec des opérateurs naturels — pas de syntaxe spéciale :

```
DECLARA x SICUT FLOTANS VALENS 3.14.
DECLARA y SICUT FLOTANS VALENS 1.5.
DECLARA z SICUT FLOTANS VALENS x + y.
PROCLAMA z.               // affiche 4.640000
```

Opérateurs supportés : `+`, `-`, `*`, `/`, et les six comparaisons
(`<`, `>`, `<=`, `>=`, `==`, `!=`). Les littéraux flottants (`3.14`,
`0.5`) fonctionnent partout où une expression est attendue, pas
seulement en initialisation :

```
DECLARA a SICUT FLOTANS VALENS 3.14.
SI a > 3.0 TUNC
    PROCLAMA 1.
FIN-SI.
DECLARA b SICUT FLOTANS VALENS 0.0 - a.
PROCLAMA b.                // affiche -3.140000
```

`PROCLAMA` d'un `FLOTANS` affiche 6 décimales (précision fixe, pas
l'arrondi "le plus court possible" d'un affichage scientifique
optimisé — largement suffisant pour un usage courant).

`FLOTANS` se passe en paramètre de fonction comme n'importe quel
autre type, en le déclarant dans `ACCIPIT` :

```
FUNCTIO DOUBLE_IT REDDENS NUMERUS.
    ACCIPIT val SICUT FLOTANS.
    DECLARA r SICUT FLOTANS VALENS val * 2.0.
    PROCLAMA r.
    REDDE 0.
FIN-FUNCTIO.

FUNCTIO PRINCIPALIS REDDENS NUMERUS.
    DECLARA x SICUT FLOTANS VALENS 3.14.
    DECLARA ig SICUT NUMERUS VALENS DOUBLE_IT(x).
    REDDE 0.
FIN-FUNCTIO.
```

`FLOTANS` fonctionne aussi comme type de champ dans une `FORMA`,
avec les mêmes opérateurs :

```
FORMA Point3D.
    CAMPUS x SICUT FLOTANS.
    CAMPUS y SICUT FLOTANS.
FIN-FORMA.

FUNCTIO PRINCIPALIS REDDENS NUMERUS.
    DECLARA p SICUT Point3D.
    x DE p = 1.5.
    y DE p = 2.5.
    DECLARA somme SICUT FLOTANS VALENS x DE p + y DE p.
    PROCLAMA somme.
    REDDE 0.
FIN-FUNCTIO.
```

## Modules multi-fichiers

`IMPORTA "fichier.vindex".` incorpore le contenu d'un autre fichier
VINDEX avant compilation (à la manière d'un `#include` du C) —
utile pour organiser un projet sur plusieurs fichiers :

```
// dans bibliotheque.vindex :
FUNCTIO CARRE REDDENS NUMERUS.
    ACCIPIT x SICUT NUMERUS.
    REDDE x * x.
FIN-FUNCTIO.

// dans principal.vindex :
IMPORTA "bibliotheque.vindex".

FUNCTIO PRINCIPALIS REDDENS NUMERUS.
    DECLARA r SICUT NUMERUS VALENS CARRE(7).
    PROCLAMA r.
    REDDE 0.
FIN-FUNCTIO.
```

Plusieurs `IMPORTA` peuvent être placés en début de fichier, un par
ligne. Le fichier importé est cherché dans le répertoire courant.

## Ligne de commande

`PRINCIPALIS` peut recevoir les arguments passés au programme, comme en
C, en les déclarant explicitement (facultatif — un programme qui n'en a
pas besoin peut les omettre) :

```
FUNCTIO PRINCIPALIS REDDENS NUMERUS.
    ACCIPIT argc SICUT NUMERUS.
    ACCIPIT argv SICUT ACUS<NUMERUS>.
    REDDE argc.
FIN-FUNCTIO.
```

`argc` est le nombre d'arguments (le nom du programme lui-même compte
comme `argv[0]`). `argv[i]` donne l'adresse de la chaîne du i-ème
argument ; pour en lire les caractères, utilisez `OCTETUS_AB` :

```
DECLARA c SICUT NUMERUS VALENS OCTETUS_AB(argv[1]).
// c contient le code ASCII du premier caractere du premier argument
```

## Lecture interactive

`LEGE` fonctionne aussi sur l'entrée standard, en utilisant le
descripteur `0` :

```
DECLARA n SICUT NUMERUS VALENS LEGE(0, 100).
SCRIBE_LECTUS(n).
```

⚠️ **`LEGE` lit tout ce qui est disponible d'un coup**, pas une ligne à
la fois — un comportement standard du système, pas propre à VINDEX. Sur
un vrai terminal interactif, chaque appel correspond typiquement à une
ligne (jusqu'à la touche Entrée). Mais si l'entrée est redirigée depuis
un fichier ou un tube (`programme < fichier` ou `echo texte | programme`)
contenant plusieurs lignes, un seul appel à `LEGE` peut toutes les
recevoir d'un coup. Pour traiter plusieurs lignes de façon fiable dans
tous les cas, il faut balayer soi-même le tampon reçu à la recherche du
caractère `10` (`\n`).

## Lancer d'autres programmes

`EXSEQUERE("commande")` lance une commande shell (`/bin/sh -c`), attend
qu'elle se termine, et retourne son code de sortie :

```
DECLARA code SICUT NUMERUS VALENS EXSEQUERE("ls -la").
PROCLAMA code.
```

C'est une fonctionnalité bas niveau à part entière : `fork`, `execve`,
`wait4` sous le capot. La sortie de la commande s'affiche directement
(elle hérite du terminal du programme VINDEX).

**Capturer la sortie** — `EXSEQUERE_CAPTURA("commande")` fonctionne
comme `popen()` en C : elle retourne un descripteur de fichier lisible
via `LEGE`, contenant tout ce que la commande a affiché :

```
DECLARA fd SICUT NUMERUS VALENS EXSEQUERE_CAPTURA("echo Salut !").
DECLARA n SICUT NUMERUS VALENS LEGE(fd, 200).
SCRIBE_LECTUS(n).
```

## Contrôle de flux

### Condition

```
SI x > 10 TUNC
    PROCLAMA 1.
ALITER
    PROCLAMA 0.
FIN-SI.
```

`ALITER` est optionnel.

### Boucle conditionnelle

```
DECLARA i SICUT NUMERUS VALENS 0.
DUM i < 10 PERFICE
    PROCLAMA i.
    i = i + 1.
FIN-DUM.
```

### Boucle bornée

```
PER i AB 0 AD 9 PERFICE
    PROCLAMA i.
FIN-PER.
```

Boucle inclusive (`AB 0 AD 9` fait 10 itérations, de 0 à 9 inclus).

⚠️ **Portée de la variable de boucle** : réutiliser le même nom de
variable dans deux boucles `PER` séparées au sein de la même fonction a
été un vrai bug jusqu'à cette session (la seconde boucle lisait la valeur
figée de la première). C'est corrigé et vérifié.

### Sortie de boucle

```
DUM i < 100 PERFICE
    SI i == 5 TUNC
        DESINE.
    FIN-SI.
    i = i + 1.
FIN-DUM.
```

`DESINE` sort de la boucle englobante (`DUM` ou `PER`).

## Opérateurs

Tous vérifiés empiriquement, y compris avec des nombres négatifs :

| Opérateur | Signification |
|---|---|
| `+` `-` `*` | Addition, soustraction, multiplication |
| `/` | Division entière signée (tronquée vers zéro) |
| `%` | Modulo signé |
| `&` `\|` | ET / OU binaire |
| `<<` `>>` | Décalage de bits gauche/droite |
| `==` `!=` `>` `<` `>=` `<=` | Comparaisons |
| `&&` `\|\|` | ET / OU logique, avec chaînage (`a && b && c`) |

Les littéraux caractères (`'A'`) sont reconnus et valent leur code ASCII.

## Entrées/sorties

```
PROCLAMA 42.                            // affiche un nombre
PROCLAMA "Texte".                       // affiche une chaine litterale
SCRIBE tableau_littera CAPACITAS n.     // affiche un tableau de LITTERA brut

DECLARA fd SICUT NUMERUS VALENS APERI_LEGERE("fichier.txt").
DECLARA n SICUT NUMERUS VALENS LEGE(fd, 1000).   // lit jusqu'a 1000 octets
CLAUDE(fd).

DECLARA fd2 SICUT NUMERUS VALENS APERI_SCRIBERE("sortie.txt").
DECLARA ecrits SICUT NUMERUS VALENS MITTE(fd2, tableau, taille).
CLAUDE(fd2).

DECLARA fd3 SICUT NUMERUS VALENS APERI_ADICERE("sortie.txt").
DECLARA ecrits2 SICUT NUMERUS VALENS MITTE(fd3, tableau, taille).
CLAUDE(fd3).
// APERI_ADICERE ajoute a la suite du fichier (comme O_APPEND en C),
// contrairement a APERI_SCRIBERE qui ecrase le contenu existant.

SCRIBE_LECTUS(n).        // affiche le contenu du dernier buffer lu par LEGE
PROCLAMA OCTETUS(0).     // acces a l'octet n du dernier buffer lu par LEGE
PROCLAMA OCTETUS_AB(p).  // acces a l'octet a l'adresse p (pointeur arbitraire)
```

## Gestion mémoire

```
DECLARA p SICUT ACUS<NUMERUS> VALENS RESERVA(NUMERUS).
LIBERA(p).
```

`RESERVA(type)` alloue dynamiquement de la mémoire sur un vrai tas
(région mémoire dédiée, distincte de la pile) — **avec la bonne taille
pour le type demandé**, y compris une structure définie par
l'utilisateur (`RESERVA(NUMERUS)` réserve 8 octets, `RESERVA(MaFORMA)`
réserve `nombre_de_champs * 8` octets). Chaque appel — y compris dans
une boucle — retourne une adresse différente, sauf réutilisation via
`LIBERA` :

```
DECLARA a SICUT ACUS<NUMERUS> VALENS RESERVA(NUMERUS).
DECLARA b SICUT ACUS<NUMERUS> VALENS RESERVA(NUMERUS).
LIBERA(a).
DECLARA c SICUT ACUS<NUMERUS> VALENS RESERVA(NUMERUS).
// c reprend exactement l'adresse de a ; b reste inchangee
```

`LIBERA(p)` remet le bloc dans une liste de blocs libres (ordre LIFO —
la dernière chose libérée est la première réutilisée), que `RESERVA`
consulte avant d'étendre le tas. **La réutilisation ne se fait que si
la taille correspond exactement** — un bloc de 8 octets libéré ne sera
jamais réutilisé pour une structure de 16 octets, et inversement,
évitant toute corruption silencieuse. Le tas dispose de 16 Mo d'espace ;
au-delà, le programme se termine proprement avec le code de sortie
`137` plutôt que de corrompre la mémoire silencieusement.

Ceci permet de vraies structures de données dynamiques, y compris
auto-référentielles (listes chaînées, arbres) :

```
FORMA Nodus.
    CAMPUS valor SICUT NUMERUS.
    CAMPUS proximus SICUT ACUS<NUMERUS>.
FIN-FORMA.

FUNCTIO PRINCIPALIS REDDENS NUMERUS.
    DECLARA n1 SICUT ACUS<NUMERUS> VALENS RESERVA(Nodus).
    DECLARA n2 SICUT ACUS<NUMERUS> VALENS RESERVA(Nodus).
    valor DE CONTENTUM(n1) = 10.
    proximus DE CONTENTUM(n1) = n2.
    valor DE CONTENTUM(n2) = 20.
    proximus DE CONTENTUM(n2) = 0.

    DECLARA courant SICUT NUMERUS VALENS n1.
    DECLARA somme SICUT NUMERUS VALENS 0.
    DUM courant != 0 PERFICE
        somme = somme + valor DE CONTENTUM(courant).
        courant = proximus DE CONTENTUM(courant).
    FIN-DUM.
    REDDE somme.
FIN-FUNCTIO.
```

## À propos d'IMPONE et AUFER

Ces deux mots figuraient dans la conception initiale du projet, dans
l'idée de fonctions natives de pile. Ce ne sont **pas** des mots-clés du
compilateur (aucune détection spéciale) — c'est volontaire :
`IMPONE`/`AUFER` sont conçues pour être **définies par le programmeur**,
comme des fonctions VINDEX ordinaires implémentant une pile sur un
tableau. C'est l'usage établi dans le projet (voir `arbor_vindex.vindex`
pour un exemple complet, avec la convention `IMPONE(tableau,
SEDES(sommet), valeur)` / `AUFER(tableau, SEDES(sommet))`).

## Limites générales

- Un seul fichier par programme — pas de `IMPORT` ni de modules.
- Linux x86-64 uniquement, format ELF statique.
- Pas de liaison avec des bibliothèques externes (pas de libc, pas de
  `printf`, etc. — tout passe par les appels système directs).
- Le code machine généré est non optimisé (verbeux : chaque opération
  produit plusieurs instructions séparées plutôt qu'une séquence
  compacte).
- 6 paramètres maximum par fonction, 100 variables locales maximum par
  fonction.

## Exemple complet

```
FORMA Compte.
    CAMPUS solde SICUT NUMERUS.
FIN-FORMA.

FUNCTIO PRINCIPALIS REDDENS NUMERUS.
    DECLARA mon_compte SICUT Compte.
    solde DE mon_compte = 100.
    solde DE mon_compte = solde DE mon_compte + 50.
    PROCLAMA solde DE mon_compte.
    REDDE 0.
FIN-FUNCTIO.
```
